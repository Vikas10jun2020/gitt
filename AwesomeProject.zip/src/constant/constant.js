export default {
  WEBSITE_URL: 'https://reactnative.dev/',
};
